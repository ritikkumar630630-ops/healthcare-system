"""
AI Symptom Checker Chatbot.
Rule-based logic that maps symptoms to specializations and suggests doctors.
"""

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import permissions
from apps.doctors.models import Doctor

# Symptom -> specialization mapping (Indian hospital common cases)
SYMPTOM_MAP = {
    'chest pain': 'Cardiologist',
    'heart': 'Cardiologist',
    'palpitations': 'Cardiologist',
    'shortness of breath': 'Pulmonologist',
    'cough': 'Pulmonologist',
    'asthma': 'Pulmonologist',
    'headache': 'Neurologist',
    'migraine': 'Neurologist',
    'seizure': 'Neurologist',
    'dizziness': 'Neurologist',
    'fever': 'General Physician',
    'cold': 'General Physician',
    'flu': 'General Physician',
    'fatigue': 'General Physician',
    'diabetes': 'Endocrinologist',
    'thyroid': 'Endocrinologist',
    'sugar': 'Endocrinologist',
    'joint pain': 'Orthopedic',
    'bone': 'Orthopedic',
    'fracture': 'Orthopedic',
    'back pain': 'Orthopedic',
    'skin': 'Dermatologist',
    'rash': 'Dermatologist',
    'acne': 'Dermatologist',
    'eye': 'Ophthalmologist',
    'vision': 'Ophthalmologist',
    'ear': 'ENT Specialist',
    'throat': 'ENT Specialist',
    'nose': 'ENT Specialist',
    'stomach': 'Gastroenterologist',
    'gastric': 'Gastroenterologist',
    'liver': 'Gastroenterologist',
    'kidney': 'Nephrologist',
    'urine': 'Nephrologist',
    'pregnancy': 'Gynecologist',
    'menstrual': 'Gynecologist',
    'child': 'Pediatrician',
    'baby': 'Pediatrician',
    'mental': 'Psychiatrist',
    'anxiety': 'Psychiatrist',
    'depression': 'Psychiatrist',
    'cancer': 'Oncologist',
    'tumor': 'Oncologist',
    'teeth': 'Dentist',
    'dental': 'Dentist',
}

GENERAL_RESPONSES = [
    "I understand you're not feeling well. Based on your symptoms, here's my suggestion:",
    "Thank you for describing your symptoms. Here's what I recommend:",
    "I've analyzed your symptoms. Here's my assessment:",
]


class SymptomCheckerView(APIView):
    """AI symptom checker — returns suggested specialization + available doctors."""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        symptoms_text = request.data.get('symptoms', '').lower().strip()

        if not symptoms_text:
            return Response({'error': 'Please describe your symptoms.'}, status=400)

        # Match symptoms to specializations
        matched_specializations = []
        for keyword, spec in SYMPTOM_MAP.items():
            if keyword in symptoms_text and spec not in matched_specializations:
                matched_specializations.append(spec)

        if not matched_specializations:
            matched_specializations = ['General Physician']

        # Fetch available doctors for matched specializations
        suggested_doctors = []
        for spec in matched_specializations[:2]:  # Limit to top 2 suggestions
            doctors = Doctor.objects.filter(
                specialization__icontains=spec,
                is_available=True
            ).select_related('user', 'department')[:3]

            for doc in doctors:
                suggested_doctors.append({
                    'id': doc.id,
                    'name': f"Dr. {doc.user.get_full_name()}",
                    'specialization': doc.specialization,
                    'department': doc.department.name if doc.department else '',
                    'consultation_fee': str(doc.consultation_fee),
                    'experience_years': doc.experience_years,
                })

        # Build chatbot response
        message = GENERAL_RESPONSES[len(symptoms_text) % len(GENERAL_RESPONSES)]

        return Response({
            'message': message,
            'symptoms_received': symptoms_text,
            'suggested_specializations': matched_specializations,
            'suggested_doctors': suggested_doctors,
            'advice': (
                'Please consult the suggested specialist. In case of emergency, '
                'visit the nearest hospital or call 108 (Ambulance) / 104 (Medical Helpline).'
            ),
        })
