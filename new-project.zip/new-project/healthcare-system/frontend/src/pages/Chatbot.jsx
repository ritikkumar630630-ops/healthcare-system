/**
 * AI Symptom Checker Chatbot — conversational UI with symptom input.
 */

import { useState, useRef, useEffect } from 'react'
import { FiSend, FiMessageSquare } from 'react-icons/fi'
import { Link } from 'react-router-dom'
import api from '../services/api'

const WELCOME = {
  type: 'bot',
  text: "Namaste! I'm MediBot, your AI health assistant. Please describe your symptoms and I'll suggest the right specialist for you.\n\n⚠️ This is for guidance only. In emergencies, call 108.",
}

export default function Chatbot() {
  const [messages, setMessages] = useState([WELCOME])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const bottomRef = useRef(null)

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])

  const sendMessage = async () => {
    const text = input.trim()
    if (!text) return
    setMessages((m) => [...m, { type: 'user', text }])
    setInput('')
    setLoading(true)
    try {
      const res = await api.post('/chatbot/symptom-check/', { symptoms: text })
      const d = res.data
      let botText = `${d.message}\n\n`
      botText += `Suggested Specialization: ${d.suggested_specializations.join(', ')}\n\n`
      if (d.suggested_doctors.length > 0) {
        botText += `Available Doctors:\n`
        d.suggested_doctors.forEach((doc) => {
          botText += `• Dr. ${doc.name.replace('Dr. ', '')} — ${doc.specialization} (${doc.experience_years}y exp) — ₹${doc.consultation_fee}\n`
        })
      }
      botText += `\n${d.advice}`
      setMessages((m) => [...m, { type: 'bot', text: botText, doctors: d.suggested_doctors }])
    } catch {
      setMessages((m) => [...m, { type: 'bot', text: 'Sorry, I could not process your query. Please try again.' }])
    } finally { setLoading(false) }
  }

  const handleKey = (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage() } }

  const quickSymptoms = ['Chest pain', 'Headache', 'Fever & cold', 'Joint pain', 'Skin rash', 'Eye problem', 'Stomach ache', 'Anxiety']

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] max-w-3xl mx-auto">
      <div className="mb-4">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
          <FiMessageSquare className="text-primary-600" /> AI Symptom Checker
        </h1>
        <p className="text-sm text-gray-500 dark:text-gray-400">Describe your symptoms to get doctor suggestions</p>
      </div>

      {/* Chat area */}
      <div className="flex-1 overflow-y-auto space-y-4 mb-4 px-1">
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}>
            {msg.type === 'bot' && (
              <div className="w-8 h-8 rounded-full bg-primary-600 flex items-center justify-center text-white text-xs font-bold mr-2 flex-shrink-0 mt-1">AI</div>
            )}
            <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm whitespace-pre-wrap ${
              msg.type === 'user'
                ? 'bg-primary-600 text-white rounded-br-sm'
                : 'bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-200 shadow-sm border border-gray-200 dark:border-gray-700 rounded-bl-sm'
            }`}>
              {msg.text}
              {msg.doctors && msg.doctors.length > 0 && (
                <div className="mt-3 space-y-2">
                  {msg.doctors.map((doc) => (
                    <Link
                      key={doc.id}
                      to="/patient/book"
                      className="flex items-center gap-2 p-2 bg-primary-50 dark:bg-primary-900/30 rounded-lg hover:bg-primary-100 transition"
                    >
                      <div className="w-7 h-7 rounded-full bg-primary-600 flex items-center justify-center text-white text-xs font-bold">{doc.name.split(' ')[1]?.[0]}</div>
                      <div>
                        <p className="text-xs font-semibold text-primary-700 dark:text-primary-400">{doc.name}</p>
                        <p className="text-xs text-gray-500">{doc.department} • ₹{doc.consultation_fee}</p>
                      </div>
                      <span className="ml-auto text-xs text-primary-600 font-medium">Book →</span>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="w-8 h-8 rounded-full bg-primary-600 flex items-center justify-center text-white text-xs font-bold mr-2">AI</div>
            <div className="bg-white dark:bg-gray-800 rounded-2xl rounded-bl-sm px-4 py-3 shadow-sm border border-gray-200 dark:border-gray-700">
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Quick symptom buttons */}
      <div className="flex gap-2 flex-wrap mb-3">
        {quickSymptoms.map((s) => (
          <button key={s} onClick={() => { setInput(s); }} className="text-xs px-3 py-1.5 rounded-full border border-gray-300 dark:border-gray-600 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition">
            {s}
          </button>
        ))}
      </div>

      {/* Input */}
      <div className="flex gap-3 items-end">
        <textarea
          className="input-field flex-1 resize-none"
          rows={2}
          placeholder="Describe your symptoms... (e.g., I have chest pain and shortness of breath)"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKey}
        />
        <button onClick={sendMessage} disabled={loading || !input.trim()} className="btn-primary p-3 rounded-xl">
          <FiSend size={18} />
        </button>
      </div>
    </div>
  )
}
