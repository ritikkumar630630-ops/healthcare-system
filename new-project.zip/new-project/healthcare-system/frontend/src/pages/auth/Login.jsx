import { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'

export default function Login() {
  const { login } = useAuth()
  const navigate = useNavigate()

  const [form, setForm] = useState({ username: '', password: '' })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [selectedRole, setSelectedRole] = useState(null)
  const [strength, setStrength] = useState('')

  // 🔥 Password strength
  useEffect(() => {
    if (form.password.length > 8) setStrength('Strong 💪')
    else if (form.password.length > 5) setStrength('Medium ⚡')
    else if (form.password.length > 0) setStrength('Weak ⚠️')
    else setStrength('')
  }, [form.password])

  // 🔥 Mouse background effect
  useEffect(() => {
    const moveBg = (e) => {
      const x = e.clientX / window.innerWidth
      const y = e.clientY / window.innerHeight
      document.body.style.backgroundPosition = `${x * 50}% ${y * 50}%`
    }
    window.addEventListener('mousemove', moveBg)
    return () => window.removeEventListener('mousemove', moveBg)
  }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')

    if (form.username.length < 3) return setError('Invalid username')
    if (form.password.length < 5) return setError('Invalid password')

    setLoading(true)

    try {
      const result = await login(form.username, form.password)

      if (result.success) {
        if (result.role === 'admin') navigate('/admin')
        else if (result.role === 'doctor') navigate('/doctor')
        else navigate('/patient')
      } else {
        setError('Wrong credentials ❌')
      }
    } catch {
      setError('Server error ⚠️')
    }

    setLoading(false)
  }

  const fillDemo = (role) => {
    const demos = {
      admin: { username: 'admin', password: 'Admin@123' },
      doctor: { username: 'dr.sharma', password: 'Doctor@123' },
      patient: { username: 'rahul.kumar', password: 'Patient@123' },
    }
    setSelectedRole(role)
    setForm(demos[role])
  }

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden">

      {/* 🌈 Animated Gradient */}
      <div className="absolute inset-0 bg-gradient-to-r from-blue-900 via-purple-900 to-indigo-900 animate-gradient"></div>

      {/* ✨ Particles */}
      <div className="absolute inset-0">
        {[...Array(40)].map((_, i) => (
          <span
            key={i}
            className="absolute w-2 h-2 bg-white/30 rounded-full animate-float"
            style={{
              top: Math.random() * 100 + "%",
              left: Math.random() * 100 + "%",
              animationDuration: 3 + Math.random() * 5 + "s"
            }}
          ></span>
        ))}
      </div>

      {/* 🔥 Overlay */}
      <div className="absolute inset-0 backdrop-blur-sm bg-black/40"></div>

      {/* 📦 Content */}
      <div className="w-full max-w-md relative z-10 px-4">

        {/* Logo */}
        <div className="text-center mb-8 animate-float">
          <div className="w-16 h-16 mx-auto bg-white rounded-2xl flex items-center justify-center shadow-xl mb-4">
            <span className="text-3xl font-bold text-blue-600">+</span>
          </div>
          <h1 className="text-3xl font-bold text-white">MediCare</h1>
          <p className="text-blue-200">Smart Healthcare System</p>
        </div>

        {/* Glass Card */}
        <div className="bg-white/20 backdrop-blur-2xl border border-white/30 rounded-2xl shadow-2xl p-8 text-white hover:scale-[1.02] transition">

          <h2 className="text-xl font-semibold mb-6">
            Welcome Back 👋
          </h2>

          {/* Demo Buttons */}
          <div className="flex gap-2 mb-4">
            {['admin', 'doctor', 'patient'].map((role) => (
              <button
                key={role}
                onClick={() => fillDemo(role)}
                className={`flex-1 py-2 text-xs rounded-lg transition-all
                ${
                  selectedRole === role
                    ? 'bg-cyan-400 text-black scale-105'
                    : 'bg-white/20 hover:bg-white/30'
                }`}
              >
                {role}
              </button>
            ))}
          </div>

          {/* Error */}
          {error && (
            <div className="bg-red-500/20 text-red-200 text-sm p-2 rounded mb-4 animate-pulse">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">

            {/* Username */}
            <input
              type="text"
              placeholder="Username"
              value={form.username}
              onChange={(e) => setForm({ ...form, username: e.target.value })}
              className="w-full px-4 py-3 rounded-lg bg-white/20 border border-white/30 text-white placeholder-white focus:ring-2 focus:ring-cyan-400 outline-none"
            />

            {/* Password */}
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                placeholder="Password"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                className="w-full px-4 py-3 rounded-lg bg-white/20 border border-white/30 text-white placeholder-white focus:ring-2 focus:ring-cyan-400 outline-none pr-10"
              />
              <span
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-3 cursor-pointer"
              >
                {showPassword ? '🙈' : '👁️'}
              </span>
            </div>

            {/* Strength */}
            {strength && (
              <p className="text-xs text-blue-200">{strength}</p>
            )}

            {/* Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gradient-to-r from-cyan-400 to-blue-500 text-white rounded-lg font-semibold hover:scale-105 transition-all shadow-lg"
            >
              {loading ? 'Loading...' : 'Sign In'}
            </button>
          </form>

          <p className="text-center text-sm mt-5 text-blue-100">
            New user?{' '}
            <Link to="/register" className="text-cyan-300 font-medium">
              Register
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}